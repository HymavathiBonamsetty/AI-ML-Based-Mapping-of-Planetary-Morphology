# Space Image Detection > 2022-11-03 8:14pm
https://universe.roboflow.com/vesit-mkptz/space-image-detection

Provided by a Roboflow user
License: CC BY 4.0

